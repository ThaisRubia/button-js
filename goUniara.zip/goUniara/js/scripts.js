const goUniara =() => {
    window.location.href = "https://www.uniara.com.br/#home-aluno";
}